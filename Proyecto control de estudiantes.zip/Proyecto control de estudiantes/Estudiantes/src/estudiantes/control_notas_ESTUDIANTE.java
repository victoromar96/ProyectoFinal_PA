/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiantes;

/**
 *
 * @author ANDRES
 */
public class control_notas_ESTUDIANTE {
    
      private sql sen;
    
    public control_notas_ESTUDIANTE()
    {
      sen = new sql();  
    }
    
    
    
    public Object[][] consulta_materia_notas(String id)
       {
        String[] columnas={"cod_carnet","cod_materia", "nombre_materia"};
        Object[][] resultado = sen.datosTabla(columnas, "materiaxestudiante", "select * from materiaxestudiante, materia where cod_materia=id_materia and  cod_carnet='"+id+"'");
        return resultado;
       
        
       }
    
    public Object[][] consultar_notas(String id)
       {
        String[] columnas1={"nota_materia","cod_materianota","cod_carnetnota"};
        Object[][] resultado1 = sen.datosTabla(columnas1,"nota", "select * from nota where nota_materia and cod_materianota and cod_carnetnota='"+id+"'");
        return resultado1;
       }
    
  public Object[][] consultar_nombres(String id)
       {
        String[] columnas2={"nombre","apellido","paralelo"};
        Object[][] resultado2 = sen.datosTabla(columnas2,"estudiante", "select * from estudiante");
        return resultado2;
       }
    
}
