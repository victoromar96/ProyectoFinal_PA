/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiantes;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;

/**
 *
 * @author JonathanAndres
 */
public class control_alumno1 {
Connection cn ;


public void  CargarTabla(JTable tabla1, String cadena){
    DefaultTableModel modelo;
    String [] titulo = {"Numero unico", "Nombre", "Apellido", "paralelo"};
    modelo = new DefaultTableModel(null, titulo);
    //AQUI FILTRO LAS BUSQUEDAS
    String [] registros = new String[4];
    String sql = "select * from estudiante where concat(id_carnet) like '%"+cadena+"%'";
    Database con = new Database();
    cn = con.getConexion();
    
    try{
        Statement st = cn.createStatement();
        ResultSet rs = st.executeQuery(sql);
        while (rs.next()){
            for (int i=0;i<4;i++)
            registros [i] = rs.getString(i+1);
            modelo.addRow(registros);
        }
        tabla1.setModel(modelo);
    }catch(SQLException ex){
        JOptionPane.showMessageDialog(null,"error" + ex);
    }
    
}

  

   
}
