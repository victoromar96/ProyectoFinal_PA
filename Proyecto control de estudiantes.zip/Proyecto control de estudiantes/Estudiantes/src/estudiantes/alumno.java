package estudiantes;

import estudiantes.Database;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.Font;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
public class alumno extends javax.swing.JFrame {
    
    public alumno() {
        initComponents();
        mostrar();
    }
    // funcion para rellenar la tabla
    private void mostrar() {        
        DefaultTableModel modelo = new DefaultTableModel();               
        ResultSet rs = Database.getTabla("Select id_carnet,documento,Tipo_doc,nombre,apellido,sexo,paralelo from estudiante");
        modelo.setColumnIdentifiers(new Object[]{"id_carnet", "documento","Tipo_doc","nombre","apellido","sexo","paralelo"});
        try {
            while (rs.next()) {
                // añade los resultado a al modelo de tabla
                modelo.addRow(new Object[]{rs.getString("id_carnet"), rs.getString("documento"), rs.getString("Tipo_doc"), rs.getString("nombre"), rs.getString("apellido"), rs.getString("sexo"), rs.getString("paralelo")});
            }            
            // asigna el modelo a la tabla
            table.setModel(modelo);            
        } catch (Exception e) {
            System.out.println(e);
        }

    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        Btnsalir = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 153, 51));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(table);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 560, 260));

        jButton1.setText("Imprimir ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, -1, -1));

        Btnsalir.setForeground(new java.awt.Color(255, 0, 0));
        Btnsalir.setText("Salir");
        Btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnsalirActionPerformed(evt);
            }
        });
        getContentPane().add(Btnsalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 280, -1, -1));

        jButton2.setText("Filtrar Busqueda");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 300, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/FONDO1.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 350));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       try{
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost/estudiantes", "root", "");
      
      
      Statement estado = con.createStatement();
      ResultSet resultado = estado.executeQuery("SELECT *  FROM  estudiante");
        
      OutputStream file = new FileOutputStream(new File("C:\\Users\\JonathanAndres\\Desktop\\impreso\\usuario.pdf"));
      Document document = new Document();
          

      PdfWriter.getInstance(document, file);
      
      document.open();
      PdfPTable tabla = new PdfPTable(7);
      Paragraph p = new Paragraph("Lista de Usuarios del sistema\n\n", FontFactory.getFont("Arial",16,Font.ITALIC,BaseColor.BLUE));
                                    
         p.setAlignment(Element.ALIGN_CENTER);
         document.add(p);

         document.add(new Paragraph(""));
         
         
           
            float[] mediaCeldas ={3.50f,3.80f,3.50f,3.70f,3.90f,3.00f,3.00f};

            tabla.setWidths(mediaCeldas);
            tabla.addCell(new Paragraph("id_carnet", FontFactory.getFont("Arial",12)));
            tabla.addCell(new Paragraph("documento", FontFactory.getFont("Arial",12)));
            tabla.addCell(new Paragraph("Tipo_doc", FontFactory.getFont("Arial",12)));
            tabla.addCell(new Paragraph("nombre", FontFactory.getFont("Arial",12)));
            tabla.addCell(new Paragraph("apellido", FontFactory.getFont("Arial",12)));
            tabla.addCell(new Paragraph("sexo", FontFactory.getFont("Arial",12)));
            tabla.addCell(new Paragraph("paralelo", FontFactory.getFont("Arial",12)));
            
                        
                        
                while (resultado.next()){
             tabla.addCell(new Paragraph(resultado.getString("id_carnet"), FontFactory.getFont("Arial",10)));                  
             tabla.addCell(new Paragraph(resultado.getString("documento"), FontFactory.getFont("Arial",10)));
             tabla.addCell(new Paragraph(resultado.getString("Tipo_doc"), FontFactory.getFont("Arial",10)));
             tabla.addCell(new Paragraph(resultado.getString("nombre"), FontFactory.getFont("Arial",10)));
             tabla.addCell(new Paragraph(resultado.getString("apellido"), FontFactory.getFont("Arial",10)));
             tabla.addCell(new Paragraph(resultado.getString("sexo"), FontFactory.getFont("Arial",10)));
             tabla.addCell(new Paragraph(resultado.getString("paralelo"), FontFactory.getFont("Arial",10)));
              
              
              
                }     
                   
             document.add(tabla);              
             document.close();
             file.close();                                         
                   
                                     
        }     
      
          catch (SQLException e){
          e.printStackTrace();
      } catch (FileNotFoundException ex) {
            Logger.getLogger(alumno.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(alumno.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(alumno.class.getName()).log(Level.SEVERE, null, ex);
        }
      
      
      try{
          File file = new File("C:\\Users\\JonathanAndres\\Desktop\\impreso\\usuario.pdf");
          Desktop.getDesktop().open(file);
       }   
      catch (Exception e){
        e.printStackTrace();
         }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void BtnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnsalirActionPerformed
         this.dispose();
    }//GEN-LAST:event_BtnsalirActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Interfaz_busqueda  bus = new Interfaz_busqueda();
  bus.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(alumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(alumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(alumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(alumno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new alumno().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btnsalir;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
