/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiantes;

/**
 *
 * @author ANDRES
 */
public class control_estudiantes {
    
    sql sensql;
   
    public control_estudiantes() {
        
        sensql = new sql();
    }

    
    /**
     *
     * @param Date
     */
    
    public boolean ingresar_estudiante(String id_carnet, String documento, String Tipo_doc, String nombre, String apellido, String sexo, String paralelo,String tipousuario)
    {               
        
            String datos[] = {id_carnet,documento,Tipo_doc,nombre,apellido,sexo,paralelo,tipousuario};           
            return sensql.insertar(datos, "insert into estudiante(id_carnet, documento,Tipo_doc,nombre,apellido,sexo,paralelo,tipousuario) values(?,?,?,?,?,?,?,?)");
                                  
        
    }

    boolean ingresar_estudiante(String carnet, String doc, String tipo, String nom, String ape, String sex, String tipousuario) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
