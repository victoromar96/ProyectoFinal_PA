/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiantes;

/**
 *
 * @author ANDRES
 */
public class control_notas {
    
      private sql sen;
    
    public control_notas()
    {
      sen = new sql();  
    }
    
    
    
    public Object[][] consulta_materia_notas(String id)
       {
        String[] columnas={"cod_carnet","cod_materia", "nombre_materia"};
        Object[][] resultado = sen.datosTabla(columnas, "materiaxestudiante", "select * from materiaxestudiante, materia where cod_materia=id_materia and  cod_carnet='"+id+"'");
        return resultado;
       
        
       }
    public Object[][] consultar_notas(String id)
       {
        String[] columnas1={"nota_materia","cod_materianota","cod_carnetnota"};
        Object[][] resultado1 = sen.datosTabla(columnas1,"nota", "select * from nota where nota_materia and cod_materianota and cod_carnetnota='"+id+"'");
        return resultado1;
       }
    
    public boolean ingresar_notas(String cod_carnetnota, String cod_materianota, Double nota)
    {               
           
            String datos[] = {cod_carnetnota, cod_materianota, Double.toString(nota)};           
            return sen.insertar(datos, "insert into nota(cod_carnetnota, cod_materianota, nota_materia) values(?,?,?)");
                                  
        
    }
    
}
