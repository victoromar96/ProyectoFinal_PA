-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-08-2018 a las 09:31:21
-- Versión del servidor: 10.1.34-MariaDB
-- Versión de PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `estudiantes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

CREATE TABLE `estudiante` (
  `id_carnet` varchar(12) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `paralelo` varchar(3) NOT NULL,
  `documento` varchar(15) NOT NULL,
  `Tipo_doc` varchar(10) NOT NULL,
  `sexo` varchar(2) NOT NULL,
  `tipousuario` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`id_carnet`, `nombre`, `apellido`, `paralelo`, `documento`, `Tipo_doc`, `sexo`, `tipousuario`) VALUES
('201241031', 'FERNANDO ', 'SANMARTIN', 'A', '1718409988', 'CEDULA', 'M', 'administrador'),
('201311111', 'JOSE ', 'BORJA', 'C', '1726873412', 'CEDULA', 'M', 'estudiante'),
('201512345', 'OMAR ', 'ESPIN', 'B', '17231234567', 'CEDULA', 'M', 'estudiante'),
('201522232', 'SOFIA', 'RODRIGUEZ', 'B', '17121314151', 'CEDULA', 'F', 'estudiante'),
('201634356', 'VALERIA', 'MENA', 'D', '18345678234', 'CEDULA', 'F', 'estudiante');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE `materia` (
  `id_materia` int(11) NOT NULL,
  `nombre_materia` varchar(20) NOT NULL,
  `intensidad_horaria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`id_materia`, `nombre_materia`, `intensidad_horaria`) VALUES
(1, 'LITERATURA', 4),
(2, 'INGLES', 1),
(3, 'QUIMICA', 1),
(4, 'HISTORIA', 1),
(5, 'PROGRAMACION', 3),
(7, 'MATEMATICA', 3),
(8, 'GEOFRAFIA', 1),
(9, 'FISICA', 1),
(10, 'SOCIALES', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiaxestudiante`
--

CREATE TABLE `materiaxestudiante` (
  `cod_carnet` varchar(12) NOT NULL,
  `cod_materia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `materiaxestudiante`
--

INSERT INTO `materiaxestudiante` (`cod_carnet`, `cod_materia`) VALUES
('201241031', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nota`
--

CREATE TABLE `nota` (
  `cod_carnetnota` varchar(12) NOT NULL,
  `cod_materianota` int(11) NOT NULL,
  `nota_materia` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `nota`
--

INSERT INTO `nota` (`cod_carnetnota`, `cod_materianota`, `nota_materia`) VALUES
('201241031', 1, 7);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD PRIMARY KEY (`id_carnet`),
  ADD KEY `cod_tipodoc_idx` (`Tipo_doc`);

--
-- Indices de la tabla `materia`
--
ALTER TABLE `materia`
  ADD PRIMARY KEY (`id_materia`);

--
-- Indices de la tabla `materiaxestudiante`
--
ALTER TABLE `materiaxestudiante`
  ADD PRIMARY KEY (`cod_carnet`,`cod_materia`) USING BTREE,
  ADD KEY `ctr_carnet_idx` (`cod_carnet`),
  ADD KEY `ctr_mat_idx` (`cod_materia`),
  ADD KEY `ctr_est_idx` (`cod_carnet`);

--
-- Indices de la tabla `nota`
--
ALTER TABLE `nota`
  ADD PRIMARY KEY (`cod_carnetnota`,`cod_materianota`),
  ADD KEY `ctr_codmatxest_idx` (`cod_materianota`),
  ADD KEY `cod_mates_idx` (`cod_materianota`),
  ADD KEY `codestrt_idx` (`cod_materianota`,`cod_carnetnota`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `materia`
--
ALTER TABLE `materia`
  MODIFY `id_materia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `materiaxestudiante`
--
ALTER TABLE `materiaxestudiante`
  ADD CONSTRAINT `ctr_est` FOREIGN KEY (`cod_carnet`) REFERENCES `estudiante` (`id_carnet`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ctr_mat` FOREIGN KEY (`cod_materia`) REFERENCES `materia` (`id_materia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `nota`
--
ALTER TABLE `nota`
  ADD CONSTRAINT `cod_mates` FOREIGN KEY (`cod_materianota`) REFERENCES `materiaxestudiante` (`cod_materia`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `codestrt` FOREIGN KEY (`cod_materianota`,`cod_carnetnota`) REFERENCES `materiaxestudiante` (`cod_materia`, `cod_carnet`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
